package com.example.wikispt.config;

import com.example.wikispt.security.CustomAuthenticationFailureHandler;
import com.example.wikispt.security.CustomUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import com.example.wikispt.security.CustomAuthenticationSuccessHandler;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final CustomAuthenticationSuccessHandler successHandler;
    private final CustomAuthenticationFailureHandler customAuthenticationFailureHandler;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration) throws Exception {

        return configuration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth

                        // Ressources publiques
                        .requestMatchers(
                                "/login",
                                "/css/**",
                                "/js/**",
                                "/images/**"
                        ).permitAll()

                        // Administration
                        .requestMatchers("/admin/**")
                        .hasRole("ADMINISTRATEUR")

                        .requestMatchers("/app/articles/nouveau", "/app/articles/modifier/**")
                        .hasRole("CONTRIBUTEUR")

                        .requestMatchers("/app/**")
                        .hasAnyRole("LECTEUR", "CONTRIBUTEUR")

                        // Lecteurs et contributeurs
                        .requestMatchers("/app/**")
                        .hasAnyRole("LECTEUR", "CONTRIBUTEUR")

                        // Toute autre requête nécessite une authentification
                        .anyRequest()
                        .authenticated()
                )
                .sessionManagement(session -> session
                        .invalidSessionStrategy((request, response) -> {
                            if (request.getRequestURI().endsWith("/login")) {
                                response.sendRedirect(request.getContextPath() + "/login");
                            } else {
                                response.sendRedirect(request.getContextPath() + "/login?expired");
                            }
                        })
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .successHandler(successHandler)
                        .failureHandler(customAuthenticationFailureHandler)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}