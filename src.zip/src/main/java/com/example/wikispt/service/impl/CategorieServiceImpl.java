package com.example.wikispt.service.impl;

import com.example.wikispt.dto.CategorieDto;
import com.example.wikispt.entity.Categorie;
import com.example.wikispt.enums.TypeAction;
import com.example.wikispt.mapper.CategorieMapper;
import com.example.wikispt.repository.CategorieRepository;
import com.example.wikispt.service.CategorieService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.example.wikispt.entity.Utilisateur;
import com.example.wikispt.service.HistoriqueService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategorieServiceImpl implements CategorieService {

    private final CategorieRepository categorieRepository;
    private final CategorieMapper categorieMapper;
    private final HistoriqueService historiqueService;
    @Override
    public Page<CategorieDto> findAll(int page, int size) {

        return categorieRepository.findAll(PageRequest.of(page, size))
                .map(this::toDtoAvecCompte);

    }

    @Override
    public List<CategorieDto> findAll() {

        return categorieRepository.findAll()
                .stream()
                .map(this::toDtoAvecCompte)
                .toList();

    }

    @Override
    public CategorieDto findById(Long id) {

        return toDtoAvecCompte(

                categorieRepository.findById(id)
                        .orElseThrow(() -> new RuntimeException("Catégorie introuvable"))

        );

    }

    @Override
    public CategorieDto save(CategorieDto dto) {

        Categorie categorie;

        if (dto.getId() == null) {

            categorie = new Categorie();

        } else {

            categorie = categorieRepository.findById(dto.getId())
                    .orElseThrow(() -> new RuntimeException("Catégorie introuvable"));

        }

        categorie.setNom(dto.getNom());
        categorie.setDescription(dto.getDescription());

        if (dto.getParentId() != null) {

            Categorie parent = categorieRepository.findById(dto.getParentId())
                    .orElseThrow(() -> new RuntimeException("Catégorie parente introuvable"));

            categorie.setParent(parent);

        } else {

            categorie.setParent(null);

        }

        categorie = categorieRepository.save(categorie);

        return categorieMapper.toDto(categorie);

    }

    @Override
    public void delete(Long id) {

        Categorie categorie = categorieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Catégorie introuvable"));

        if (!categorie.getArticles().isEmpty()) {
            throw new RuntimeException(
                    "Impossible de supprimer : " + categorie.getArticles().size() +
                            " article(s) appartiennent à cette catégorie.");
        }

        if (!categorie.getSousCategories().isEmpty()) {
            throw new RuntimeException(
                    "Impossible de supprimer : cette catégorie contient " +
                            categorie.getSousCategories().size() + " sous-catégorie(s).");
        }

        historiqueService.enregistrer(TypeAction.SUPPRESSION_CATEGORIE,
                "Suppression de la catégorie « " + categorie.getNom() + " »",
                utilisateurConnecteCourant());

        categorieRepository.delete(categorie);

    }

    private Utilisateur utilisateurConnecteCourant() {
        var auth = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication();
        return (Utilisateur) auth.getPrincipal();
    }

    @Override
    public Page<CategorieDto> rechercher(String motCle, int page, int size) {

        return categorieRepository
                .findByNomContainingIgnoreCase(motCle, PageRequest.of(page, size))
                .map(this::toDtoAvecCompte);

    }

    private CategorieDto toDtoAvecCompte(Categorie categorie) {
        CategorieDto dto = categorieMapper.toDto(categorie);
        dto.setNombreArticles(categorie.getArticles().size());
        return dto;
    }

}